import React from "react";
import Editor from "./components/Editor";

function App() {
  return (
    <>
      <Editor />
    </>
  );
}

export default App;
